<?php // $Id: postgres7.php,v 1.21 2006/04/24 09:00:43 vyshane Exp $

function registration_upgrade($oldversion) {
// This function does anything necessary to upgrade
// older versions to match current functionality


    return true;
}


?>
