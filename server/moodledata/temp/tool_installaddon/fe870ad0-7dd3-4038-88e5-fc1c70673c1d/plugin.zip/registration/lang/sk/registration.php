<?php
$string['or'] = "alebo";
$string['closed'] = "Termín je uzavretý";
$string['duedate'] = 'Dátum';
$string['early'] = '{$a} vèas';
$string['feedback'] = "Odpoveï";
$string['full'] = "Termín je plne obsadený";
$string['late'] = '{$a} neskoro';
$string['maximumpoints'] = 'Maximálny poèet bodov';
$string['note'] = 'Poznámka';
$string['order'] = "Poradie";
$string['place'] = 'Miestnos»';
$string['points'] = 'Body';
$string['pointsplural'] = 'bodov';
$string['printversionid'] = 'Verzia pre tlaè: bez mena';
$string['printversionname'] = 'Verzia pre tlaè: s menom';
$string['registeredon'] = 'Prihlásenie na';
$string['registrations'] = 'Poèty';
$string['submissions'] = 'Odovzdané zadania';
?>
